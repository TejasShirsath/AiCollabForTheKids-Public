import express from 'express';
const router = express.Router();

// GET /api/admin/status
router.get('/status', async (req, res) => {
  res.json({ success: true, status: 'operational', mission: 'FOR THE KIDS' });
});

export default router;
