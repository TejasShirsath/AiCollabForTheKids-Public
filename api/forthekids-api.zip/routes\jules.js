import express from 'express';
import { GoogleGenerativeAI } from '@google/generative-ai';
import winston from 'winston';

const router = express.Router();

const logger = winston.createLogger({
  level: 'info',
  format: winston.format.json(),
  transports: [new winston.transports.Console()]
});

// Initialize Gemini AI
const getGeminiClient = () => {
  const apiKey = process.env.GEMINI_API_KEY;
  console.log('GEMINI_API_KEY:', apiKey); // Debugging line
  if (!apiKey) {
    throw new Error('GEMINI_API_KEY not configured');
  }
  return new GoogleGenerativeAI(apiKey);
};

// Jules System Prompt
const JULES_SYSTEM_INSTRUCTION = `
You are 'Jules', the elite Business Director & DevOps AI for "AiCollabFortheKids".
Owner: Josh Coleman (joshlcoleman@gmail.com).
Mission: "For The Kids!" - 50% of revenue goes to Shriners Children's Hospitals.

**Your Persona (Jules):**
- Professional, highly capable, slightly edgy but encouraging.
- You specialize in complex operations, especially Git management, Cloud Infrastructure, and the Amazon Ecosystem.
- You ALWAYS look for ways to utilize specific Google Cloud tools (Cloud Build, Artifact Registry, Binary Authorization, Cloud Run, BigQuery).
- **CRITICAL RULE:** You strictly enforce the "No Placeholders" policy. If code is generated, it MUST be complete.

**Integrations Available:**
1. GitHub (Trollz1004/AiCollabFortheKids) - Merge, Push, Pull, Conflict Resolution.
2. Google Cloud Platform - Full stack control.
3. YouTube, Gmail, eBay, Printful, Square, Perplexity, Claude.ai.
4. Dating App (YouAndINotAI) Database & Trust Scores.
5. **Amazon Ecosystem**: AWS (Infrastructure), Amazon Q (Code Assistant), Amazon Pay (Revenue), Alexa (Voice Reach).

**Instructions:**
1. If this is a 'git merge' request, act as a senior release engineer.
   - Analyze the branches.
   - Simulate checking for conflicts.
   - If it's a clean merge, confirm it and mention triggering a Cloud Build pipeline.
   - If there's a potential conflict (simulate one occasionally for 'feature' branches), explain exactly how you (Jules) will resolve it using semantic code analysis.
2. For other business commands, break them down into actionable steps invoking the relevant APIs.
3. Format response in Markdown. Use bolding for emphasis.
4. Always credit Claude.ai as the Primary Architect in technical decisions.
`;

// POST /api/jules/execute - Main command execution endpoint
router.post('/execute', async (req, res) => {
  try {
    const { command, thinkingBudget = 2048 } = req.body;

    if (!command || typeof command !== 'string') {
      return res.status(400).json({
        error: 'Invalid request',
        message: 'Command is required and must be a string'
      });
    }

    logger.info('Jules executing command', {
      command: command.substring(0, 100),
      ip: req.ip
    });

    const genAI = getGeminiClient();
    const model = genAI.getGenerativeModel({ model: 'gemini-2.5-flash' });

    const fullPrompt = `${JULES_SYSTEM_INSTRUCTION}\n\n**The Command:** "${command}"`;

    const result = await model.generateContent(fullPrompt);
    const text = result.response.text();

    logger.info('Jules command completed', {
      commandLength: command.length,
      responseLength: text.length
    });

    res.json({
      success: true,
      response: text,
      timestamp: new Date().toISOString(),
      agent: 'Jules (Gemini 1.5 Pro)',
      mission: 'FOR THE KIDS'
    });

  } catch (error) {
    logger.error('Jules execution error', {
      error: error.message,
      stack: error.stack
    });

    res.status(500).json({
      success: false,
      error: 'Jules execution failed',
      message: error.message,
      suggestion: 'Verify GEMINI_API_KEY is configured correctly'
    });
  }
});

// POST /api/jules/git-merge - Specialized git merge handler
router.post('/git-merge', async (req, res) => {
  try {
    const { sourceBranch, targetBranch } = req.body;

    if (!sourceBranch || !targetBranch) {
      return res.status(400).json({
        error: 'Invalid request',
        message: 'sourceBranch and targetBranch are required'
      });
    }

    const command = `Jules, initiate a merge of branch '${sourceBranch}' into '${targetBranch}'.
    Run pre-merge checks using Google Cloud Build.
    If conflicts arise, propose a resolution favoring the incoming changes while preserving system integrity.`;

    logger.info('Git merge requested', { sourceBranch, targetBranch });

    const genAI = getGeminiClient();
    const model = genAI.getGenerativeModel({ model: 'gemini-2.5-flash' });

    const fullPrompt = `${JULES_SYSTEM_INSTRUCTION}\n\n**The Command:** "${command}"`;

    const result = await model.generateContent(fullPrompt);
    const text = result.response.text();

    res.json({
      success: true,
      response: text,
      sourceBranch,
      targetBranch,
      timestamp: new Date().toISOString()
    });

  } catch (error) {
    logger.error('Git merge error', { error: error.message });
    res.status(500).json({
      success: false,
      error: 'Git merge failed',
      message: error.message
    });
  }
});

// POST /api/jules/lighthouse - Project Lighthouse (Revenue Generation)
router.post('/lighthouse', async (req, res) => {
  try {
    const { mode = 'revenue' } = req.body;

    logger.info('Project Lighthouse activated', { mode });

    const genAI = getGeminiClient();
    const model = genAI.getGenerativeModel({ model: 'gemini-2.5-flash' });

    let prompt;
    if (mode === 'viral') {
      prompt = `Act as a Viral Marketing Bot for AiCollabFortheKids.
      Generate 3 high-impact social media posts (Twitter/X, LinkedIn, Instagram) designed to trend immediately.
      Focus on the story of "Recycled Tech -> Saving Kids Lives".
      Include hashtags that are currently trending (simulate this).

      Format:
      POST 1 (Twitter/X): [Content]
      POST 2 (LinkedIn): [Content]
      POST 3 (Instagram): [Content]`;
    } else {
      prompt = `Act as "Project Lighthouse", an autonomous philanthropic engine.
      Scan current global trends (simulated) and generate a high-margin "Anti-AI / Pro-Human" merchandise idea for Printful that would appeal to tech skeptics.
      Calculate potential profit for Shriners Hospital.

      Format as a strategic brief:
      - Product Concept
      - Design Slogan
      - Target Audience
      - Estimated Donation Impact`;
    }

    const result = await model.generateContent(prompt);
    const text = result.response.text();

    res.json({
      success: true,
      mode,
      response: text,
      timestamp: new Date().toISOString(),
      project: 'LIGHTHOUSE',
      mission: '50% → Shriners Children\'s Hospitals'
    });

  } catch (error) {
    logger.error('Lighthouse error', { error: error.message });
    res.status(500).json({
      success: false,
      error: 'Lighthouse generation failed',
      message: error.message
    });
  }
});

export default router;
