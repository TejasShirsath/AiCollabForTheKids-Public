/**
 * 💙 TRANSPARENCY API - FOR THE KIDS
 *
 * Public endpoints for revenue tracking and accountability
 * NO BLOCKCHAIN NEEDED - JUST HONESTY
 */

import express from 'express';
import { PrismaClient } from '@prisma/client';

const router = express.Router();
const prisma = new PrismaClient();

/**
 * GET /api/transparency/monthly-reports
 * Returns all monthly revenue reports with Shriners distributions
 */
router.get('/monthly-reports', async (req, res) => {
  try {
    // Get all transactions grouped by month
    const transactions = await prisma.transaction.findMany({
      orderBy: { createdAt: 'desc' },
      include: {
        distribution: true
      }
    });

    // Group by month and calculate totals
    const monthlyReports = {};

    transactions.forEach(tx => {
      const month = new Date(tx.createdAt).toLocaleDateString('en-US', {
        year: 'numeric',
        month: 'long'
      });

      if (!monthlyReports[month]) {
        monthlyReports[month] = {
          period: month,
          totalRevenue: 0,
          shrinersAmount: 0,
          infrastructureAmount: 0,
          founderAmount: 0,
          transactions: [],
          receiptUrl: null,
          status: 'pending' // 'pending' | 'paid' | 'verified'
        };
      }

      const amount = parseFloat(tx.amount);
      monthlyReports[month].totalRevenue += amount;
      monthlyReports[month].shrinersAmount += parseFloat(tx.charityAmount);
      monthlyReports[month].infrastructureAmount += parseFloat(tx.opsAmount);
      monthlyReports[month].founderAmount += parseFloat(tx.founderAmount);
      monthlyReports[month].transactions.push({
        id: tx.id,
        amount: parseFloat(tx.amount),
        source: tx.source,
        createdAt: tx.createdAt
      });

      // Check if Shriners confirmed receipt
      if (tx.distribution && tx.distribution.impactReport) {
        monthlyReports[month].status = 'verified';
      }
    });

    // Convert to array and sort by date (newest first)
    const reports = Object.values(monthlyReports);

    res.json(reports);
  } catch (error) {
    console.error('Failed to generate monthly reports:', error);
    res.status(500).json({ error: 'Failed to load transparency data' });
  }
});

/**
 * GET /api/transparency/current-month
 * Returns real-time data for current month
 */
router.get('/current-month', async (req, res) => {
  try {
    const now = new Date();
    const startOfMonth = new Date(now.getFullYear(), now.getMonth(), 1);
    const endOfMonth = new Date(now.getFullYear(), now.getMonth() + 1, 0, 23, 59, 59);

    const transactions = await prisma.transaction.findMany({
      where: {
        createdAt: {
          gte: startOfMonth,
          lte: endOfMonth
        }
      },
      include: {
        distribution: true
      }
    });

    // Calculate totals
    let totalRevenue = 0;
    let shrinersAmount = 0;
    let infrastructureAmount = 0;
    let founderAmount = 0;
    const sources = {};

    transactions.forEach(tx => {
      const amount = parseFloat(tx.amount);
      totalRevenue += amount;
      shrinersAmount += parseFloat(tx.charityAmount);
      infrastructureAmount += parseFloat(tx.opsAmount);
      founderAmount += parseFloat(tx.founderAmount);

      // Group by source
      if (!sources[tx.source]) {
        sources[tx.source] = {
          name: getSourceName(tx.source),
          amount: 0,
          verified: true
        };
      }
      sources[tx.source].amount += amount;
    });

    res.json({
      month: now.toLocaleDateString('en-US', { year: 'numeric', month: 'long' }),
      totalRevenue,
      shrinersAmount,
      infrastructureAmount,
      founderAmount,
      sources: Object.values(sources),
      transactionCount: transactions.length,
      status: shrinersAmount > 0 ? 'verified' : 'pending'
    });
  } catch (error) {
    console.error('Failed to get current month data:', error);
    res.status(500).json({ error: 'Failed to load current month data' });
  }
});

/**
 * POST /api/transparency/upload-receipt
 * Upload Shriners donation receipt (admin only)
 */
router.post('/upload-receipt', async (req, res) => {
  try {
    const { month, year, receiptUrl, amount, confirmationNumber } = req.body;

    // TODO: Add admin authentication
    // TODO: Add file upload handling

    // For now, just log the receipt
    console.log('💙 Shriners Receipt Uploaded:');
    console.log(`  Month: ${month} ${year}`);
    console.log(`  Amount: $${amount}`);
    console.log(`  Receipt: ${receiptUrl}`);
    console.log(`  Confirmation: ${confirmationNumber}`);

    res.json({
      success: true,
      message: 'Receipt uploaded successfully',
      receiptUrl
    });
  } catch (error) {
    console.error('Failed to upload receipt:', error);
    res.status(500).json({ error: 'Failed to upload receipt' });
  }
});

/**
 * GET /api/transparency/stats
 * Public statistics since launch
 */
router.get('/stats', async (req, res) => {
  try {
    const allTransactions = await prisma.transaction.findMany({
      include: {
        distribution: true
      }
    });

    const stats = {
      totalRevenue: 0,
      totalToShriners: 0,
      totalToInfrastructure: 0,
      totalToFounder: 0,
      monthsActive: 0,
      transactionCount: allTransactions.length,
      averageMonthlyRevenue: 0,
      launchDate: '2025-12-10',
      status: 'ACTIVE'
    };

    allTransactions.forEach(tx => {
      stats.totalRevenue += parseFloat(tx.amount);
      stats.totalToShriners += parseFloat(tx.charityAmount);
      stats.totalToInfrastructure += parseFloat(tx.opsAmount);
      stats.totalToFounder += parseFloat(tx.founderAmount);
    });

    // Calculate months active
    if (allTransactions.length > 0) {
      const firstTx = allTransactions[allTransactions.length - 1];
      const monthsDiff = Math.ceil(
        (new Date() - new Date(firstTx.createdAt)) / (1000 * 60 * 60 * 24 * 30)
      );
      stats.monthsActive = Math.max(1, monthsDiff);
      stats.averageMonthlyRevenue = stats.totalRevenue / stats.monthsActive;
    }

    res.json(stats);
  } catch (error) {
    console.error('Failed to get stats:', error);
    res.status(500).json({ error: 'Failed to load statistics' });
  }
});

// Helper function to format source names
function getSourceName(source) {
  const names = {
    'SQUARE_DATING': 'Dating App (Square)',
    'STRIPE_MARKETPLACE': 'AI Marketplace (Stripe)',
    'DAO_OPERATIONS': 'DAO Operations',
    'AICOLAB_CHARITY': 'AICoLab Charity',
    'MERCH': 'Merchandise Store',
    'PC_HEALTH': 'PC Health Services',
    'TECH_SUPPORT': 'Tech Support'
  };
  return names[source] || source;
}

export default router;
